public class Main {
    public static void main(String[] args) {
        // Create a new refugio
        Refugio refugio = new Refugio("Refugio de animales");

        // Create a new adoptante
        Adoptante adoptante = new Adoptante("Adoptante", "Adoptante", "12345678A");

        // Create a new animal
        Animal animal = new Animal("Animal", "Animal description", "Animal breed", "Animal color");
    }
}
